package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Reports;

public class PaymentInfoPage {
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	
	
	public PaymentInfoPage(WebDriver driver, ExtentTest test) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;
	}
	
	
	public boolean Payment() {
		
		driver.findElement(Locators.FinishButton).click();
		boolean actResult = true;
		try {
			//explicit wait for Products text
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h2[text()='Thank you for your order!']")));
			Reports.generateReport(driver, test, Status.PASS,"Payment is success");
	
		}catch(TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL,"Payment is failure");
		}
		return actResult;
		
	}

}
