package pages;

import java.time.Duration;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Reports;

public class ProductListPage {
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	
	
	public ProductListPage(WebDriver driver, ExtentTest test) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;
	}
	
	public boolean selectProduct() {
		driver.findElement(Locators.firstProduct).click();
		
		boolean actResult = true;
		
		try {
			//explicit wait for Products text
			wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.backToProduct));
			Reports.generateReport(driver, test, Status.PASS,"Selecting the product is success");
	
		}catch(TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.PASS,"Selecting the product is failure");
		}
		return actResult;
	}
	

}
