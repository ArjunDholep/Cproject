package pages;

import java.time.Duration;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Reports;

public class CheckOutPage {
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	
	
	public CheckOutPage(WebDriver driver, ExtentTest test) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;
	}
	
	
	public boolean Checkout() {
		boolean actResult = true;
		driver.findElement(Locators.CheckOutbutton).click();
		try {
			//explicit wait for Products text
			wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.CheckOutInfo));
			Reports.generateReport(driver, test, Status.PASS,"Checkout is success");
	
		}catch(TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL,"Checkout is failure");
		}
		return actResult;

}
	
}
