package pages;

import java.time.Duration;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Reports;

public class CustomerInformationPage {
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	
	
	public CustomerInformationPage(WebDriver driver, ExtentTest test) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;
	}
	
	
	public boolean CustomerInfo(String First_name,String Last_Name,String PinCode) {
		
		driver.findElement(Locators.FirstName).sendKeys(First_name);
		driver.findElement(Locators.LastName).sendKeys(Last_Name);;
		driver.findElement(Locators.postalcode).sendKeys(PinCode);
		driver.findElement(Locators.continuebutton1).click();
		boolean actResult = true;
		try {
			//explicit wait for Products text
			wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.paymentinfo));
			Reports.generateReport(driver, test, Status.PASS,"Customer Details is populated");
	
		}catch(TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL,"Customer Details is not populated");
		}
		return actResult;

}

}
