package pages;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Base;
import utils.Reports;

public class LoginPage {
	private WebDriver driver ;
	private WebDriverWait wait;
	ExtentTest test;

//	//Locator for login page
//		public static By userName = By.id("user-name");
//		public static By password = By.id("password");
//		public static By loginButton = By.id("login-button");
//		
	public LoginPage(WebDriver driver, ExtentTest test) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		this.test = test;
	}

	public boolean validUrl() {
		String currUrl = driver.getCurrentUrl();
		
		boolean actResult;
		if (currUrl.equals("https://www.saucedemo.com/")) {
			actResult = true;
			Reports.generateReport(driver, test, Status.PASS, "Sauce demo is launched Successful");
		} else {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL, "Sauce demo is launched failure");
		}
		
		return actResult;

	}

	// code for login operations
	public boolean validateLogin(String uname, String pwd) {
		driver.findElement(Locators.userName).sendKeys(uname);
		
		driver.findElement(Locators.password).sendKeys(pwd);
		
		driver.findElement(Locators.loginButton).click();
         
		boolean actResult = true;
		
		try {
			// explicit wait for Products text
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Products']")));
			Reports.generateReport(driver, test, Status.PASS, "Login is Successful");
		} catch (TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL, "Login is failure");
//			String userDir = System.getProperty("user.dir");
//			String screenShotName = userDir + "\\screenshots\\" +captureScreenshot("Login Failure");			

		}
		
	    return actResult;

	}

}
