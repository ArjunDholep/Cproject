package pages;

import java.time.Duration;

import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import objectrepo.Locators;
import utils.Reports;

public class LogOutPage {
	private WebDriver driver;
	private WebDriverWait wait;
	ExtentTest test;
	
	
	public LogOutPage(WebDriver driver, ExtentTest test) {
		super();
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		this.test = test;
	}
	
	
	public boolean LogOut() {
				boolean actResult = true;
			
		try {
			driver.findElement(Locators.MenuButton).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(Locators.LogoutButton));
			Reports.generateReport(driver, test, Status.PASS,"Logout is success");
			
			driver.findElement(Locators.LogoutButton).click();
				
	
		}catch(TimeoutException te) {
			actResult = false;
			Reports.generateReport(driver, test, Status.FAIL,"Logout is failure");
		}
		return actResult;
}
	}
