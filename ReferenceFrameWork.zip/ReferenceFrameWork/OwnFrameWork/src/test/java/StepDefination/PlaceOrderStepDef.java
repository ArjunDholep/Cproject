package StepDefination;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddToCartPage;
import pages.CheckOutPage;
import pages.CompletePage;
import pages.CustomerInformationPage;
import pages.LogOutPage;
import pages.LoginPage;
import pages.PaymentInfoPage;
import pages.ProductInCartPage;
import pages.ProductListPage;
import utils.Base;

public class PlaceOrderStepDef extends Base{
	
	WebDriver driver = Base.driver;
	ExtentTest test = Hooks.test;

	LoginPage loginPage;
	ProductListPage productListPage;
	AddToCartPage addtocart;
	ProductInCartPage Cart;
	CheckOutPage checkout;
	CustomerInformationPage Customerinfo;
	PaymentInfoPage paymentinfo;
	LogOutPage Logout;
	CompletePage CompleteMsg;
		
	
	@Given("the use is on login page")
	public void the_use_is_on_login_page() {
		loginPage = new LoginPage(driver, test);
		boolean actResult =loginPage.validUrl();
		Assert.assertTrue(actResult);
	}

	@When("the user enters {string} and {string} and click login button")
	public void the_user_enters_and_and_click_login_button(String Username,String Password) {
		boolean actResult =loginPage.validateLogin(Username, Password);
		Assert.assertTrue(actResult);
	}

	@When("user selects the product")
	public void user_selects_the_product() {
		productListPage = new ProductListPage(driver, test);
		boolean actResult =productListPage.selectProduct();
		Assert.assertTrue(actResult);
	    
	}

	@When("user clicks add to cart button")
	public void user_clicks_add_to_cart_button() {
		addtocart =  new AddToCartPage(driver, test);
		boolean actResult =addtocart.AddtoCartButton();
		Assert.assertTrue(actResult);
	}

	@When("user clicks cart button")
	public void user_clicks_cart_button() {
		Cart = new ProductInCartPage(driver, test);
		boolean actResult =Cart.Prodincart();
		Assert.assertTrue(actResult);
	    
	}

	@When("user clicks checkout button")
	public void user_clicks_checkout_button() {
		checkout = new CheckOutPage(driver, test);
		boolean actResult =checkout.Checkout();
		Assert.assertTrue(actResult);
	}

	@When("user enter {string},{string},{string} and click continue button")
	public void user_enter_and_click_continue_button(String FirstName, String LastName, String PinCode) {
		Customerinfo = new CustomerInformationPage(driver, test);
		boolean actResult = Customerinfo.CustomerInfo(FirstName,LastName,PinCode);
			Assert.assertTrue(actResult);
	}
	

	@Then("user verifies product information and click Finish button")
	public void user_verifies_product_information_and_click_finish_button() {
		paymentinfo = new PaymentInfoPage(driver, test);
		boolean actResult = paymentinfo.Payment();
		Assert.assertTrue(actResult);
	}

	@Then("user verifies checkout complete message")
	public void user_verifies_checkout_complete_message() {
		CompleteMsg = new CompletePage(driver, test);
		boolean actResult = CompleteMsg.CompleteMessage();
		Assert.assertTrue(actResult);    
	}

	@Then("the user logout")
	public void the_user_logout() {
		Logout = new LogOutPage(driver, test);
		boolean actResult = Logout.LogOut();
		Assert.assertTrue(actResult);
		
	}

}
