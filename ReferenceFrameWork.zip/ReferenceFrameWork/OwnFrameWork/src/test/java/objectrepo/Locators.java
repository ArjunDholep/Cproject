package objectrepo;

import org.openqa.selenium.By;

public class Locators {
	//Locator for login page
	public static By userName = By.id("user-name");
	public static By password = By.id("password");
	public static By loginButton = By.id("login-button");
	
	//Locators for ProductListPage
	public static By firstProduct = By.xpath("(//div[@class='inventory_item_name '])[1]");
	public static By backToProduct = By.id("back-to-products");
    
	//Locators for AddtoCart
	
	public static By AddtoCartButton = By.id("add-to-cart");
	public static By RemoveButton = By.id("remove");
	
	//Locators for ProductInCart
	
	public static By CartSymbol = By.xpath("//a[@class='shopping_cart_link']");
	public static By CartInvetory = By.xpath("//div[@class='inventory_item_name']");
	
	//Locators for CheckOut
	public static By CheckOutbutton = By.id("checkout");
	public static By CheckOutInfo = By.xpath("//span[text()='Checkout: Your Information']");
	
	//Locators for CustomerInformation
	public static By FirstName = By.id("first-name");
	public static By LastName = By.id("last-name");
	public static By postalcode = By.id("postal-code");
	public static By continuebutton1 = By.id("continue");
	public static By paymentinfo = By.xpath("//div[@data-test='payment-info-label']");
	
	//Locators for PaymentInfo
	public static By FinishButton = By.id("finish");
	
	//Locators for logOut
	public static By MenuButton = By.id("react-burger-menu-btn");
	public static By LogoutButton = By.id("logout_sidebar_link");
	
	
	
	
	
}
